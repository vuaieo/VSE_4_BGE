# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "VSE_Sounds_4_BGE",
    "author" : "vuaieo", 
    "description" : "1 button feature to render and load the sound from Frame start to Frame End so can use for blender game engines because in blneder by default if cutting the sound or shortening then in game engine it still plays as whole original lengh...",
    "blender" : (3, 6, 2),
    "version" : (1, 0, 0),
    "location" : "Video Sequence Editor on Header...",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "Sequencer" 
}


import bpy
import bpy.utils.previews


addon_keymaps = {}
_icons = None
make_strip_final_by_save_and_reload_file = {'sna_original_first_frame_of_playback': 0, 'sna_original_final_frame_of_playback': 0, 'sna_cursor_location': 0.0, 'sna_preview_range_used': False, 'sna_active_sequence_strip_name': '', }
class SNA_OT_Fade_In_Eb43D(bpy.types.Operator):
    bl_idname = "sna.fade_in_eb43d"
    bl_label = "Fade in"
    bl_description = "animates the volume so that the sound Volume of the strip is 0 at start and it ends to 1 on the cursor"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.sequencer.fades_add('INVOKE_DEFAULT', type='CURSOR_TO')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Fade_Out_Ea146(bpy.types.Operator):
    bl_idname = "sna.fade_out_ea146"
    bl_label = "Fade Out"
    bl_description = "animates the volume so that the sound Volume of the strip is 0 at start and ends to 1 on the cursor"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.sequencer.fades_add('INVOKE_DEFAULT', type='CURSOR_FROM')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Range_To_Strips_0924B(bpy.types.Operator):
    bl_idname = "sna.set_range_to_strips_0924b"
    bl_label = "Set Range to Strips"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if bpy.context.scene.use_preview_range:
            bpy.ops.sequencer.set_range_to_strips('INVOKE_DEFAULT', preview=True)
        else:
            bpy.ops.sequencer.set_range_to_strips('INVOKE_DEFAULT', )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_add_to_sequencer_ht_header_37117(self, context):
    if not (False):
        layout = self.layout
        op = layout.operator('sna.set_range_to_strips_0924b', text='Set Range to Strips', icon_value=0, emboss=True, depress=False)


def sna_add_to_sequencer_ht_header_D40D3(self, context):
    if not (False):
        layout = self.layout
        op = layout.operator('sna.fade_in_eb43d', text='Volume Fade in to Cursor', icon_value=0, emboss=True, depress=False)


def sna_add_to_sequencer_ht_header_63D55(self, context):
    if not (False):
        layout = self.layout
        op = layout.operator('sna.fade_out_ea146', text='Volume Fade out after Cursor', icon_value=0, emboss=True, depress=False)


class SNA_OT_Make_Strip_Real_34Bd4(bpy.types.Operator):
    bl_idname = "sna.make_strip_real_34bd4"
    bl_label = "Make Strip Real"
    bl_description = "it renders the Sound Strip from Frame start to Frame end and then add it to VSE back . works with Preview range ( alternative timeline ) too. the sounds strip is packed into blend file by default, it auto adding the string: 'BGES_' in front of the sound name for faster reminding to use on game engine nodes..."
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        make_strip_final_by_save_and_reload_file['sna_original_first_frame_of_playback'] = bpy.context.scene.frame_start
        make_strip_final_by_save_and_reload_file['sna_original_final_frame_of_playback'] = bpy.context.scene.frame_end
        make_strip_final_by_save_and_reload_file['sna_cursor_location'] = bpy.context.scene.frame_current
        make_strip_final_by_save_and_reload_file['sna_active_sequence_strip_name'] = bpy.context.active_sequence_strip.name
        if '.flac' in bpy.context.active_sequence_strip.name:
            bpy.context.active_sequence_strip.name = bpy.context.active_sequence_strip.name.split('.flac')[0]
            if 'BGES_' in bpy.context.active_sequence_strip.name:
                pass
            else:
                bpy.context.active_sequence_strip.name = 'BGES_' + bpy.context.active_sequence_strip.name
        if bpy.context.scene.use_preview_range:
            bpy.context.scene.frame_start = bpy.context.scene.frame_preview_start
            bpy.context.scene.frame_end = bpy.context.scene.frame_preview_end
            make_strip_final_by_save_and_reload_file['sna_preview_range_used'] = True
        prev_context = bpy.context.area.type
        bpy.context.area.type = 'FILE_BROWSER'
        bpy.ops.sound.mixdown('INVOKE_DEFAULT', filepath=bpy.app.tempdir + bpy.context.active_sequence_strip.name + '.flac', accuracy=1)
        bpy.context.area.type = prev_context
        bpy.context.scene.frame_current = bpy.context.scene.frame_start
        bpy.ops.sequencer.sound_strip_add('INVOKE_DEFAULT', filepath=bpy.app.tempdir + bpy.context.active_sequence_strip.name + '.flac')
        bpy.context.scene.sequence_editor.sequences_all[bpy.context.active_sequence_strip.name].show_waveform = True
        bpy.context.scene.frame_current = make_strip_final_by_save_and_reload_file['sna_cursor_location']
        if make_strip_final_by_save_and_reload_file['sna_preview_range_used']:
            bpy.context.scene.frame_start = make_strip_final_by_save_and_reload_file['sna_original_first_frame_of_playback']
            bpy.context.scene.frame_end = make_strip_final_by_save_and_reload_file['sna_original_final_frame_of_playback']
            make_strip_final_by_save_and_reload_file['sna_preview_range_used'] = False
        bpy.ops.sound.pack('INVOKE_DEFAULT', )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_add_to_sequencer_ht_header_235ED(self, context):
    if not (False):
        layout = self.layout
        op = layout.operator('sna.make_strip_real_34bd4', text='Make Strip Real', icon_value=0, emboss=True, depress=False)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.utils.register_class(SNA_OT_Fade_In_Eb43D)
    bpy.utils.register_class(SNA_OT_Fade_Out_Ea146)
    bpy.utils.register_class(SNA_OT_Set_Range_To_Strips_0924B)
    bpy.types.SEQUENCER_HT_header.append(sna_add_to_sequencer_ht_header_37117)
    bpy.types.SEQUENCER_HT_header.append(sna_add_to_sequencer_ht_header_D40D3)
    bpy.types.SEQUENCER_HT_header.append(sna_add_to_sequencer_ht_header_63D55)
    bpy.utils.register_class(SNA_OT_Make_Strip_Real_34Bd4)
    bpy.types.SEQUENCER_HT_header.append(sna_add_to_sequencer_ht_header_235ED)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    bpy.utils.unregister_class(SNA_OT_Fade_In_Eb43D)
    bpy.utils.unregister_class(SNA_OT_Fade_Out_Ea146)
    bpy.utils.unregister_class(SNA_OT_Set_Range_To_Strips_0924B)
    bpy.types.SEQUENCER_HT_header.remove(sna_add_to_sequencer_ht_header_37117)
    bpy.types.SEQUENCER_HT_header.remove(sna_add_to_sequencer_ht_header_D40D3)
    bpy.types.SEQUENCER_HT_header.remove(sna_add_to_sequencer_ht_header_63D55)
    bpy.utils.unregister_class(SNA_OT_Make_Strip_Real_34Bd4)
    bpy.types.SEQUENCER_HT_header.remove(sna_add_to_sequencer_ht_header_235ED)
